package com.example.happyweight.models;

public class AddWeightRecord {
}
