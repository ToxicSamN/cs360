# Happy Weight
This repo will not run if downloaded. 
There is a google firebase API key and configuration that is required in order to make this work. 
Instead download the APK from 
https://github.com/ToxicSamN/cs360/blob/master/SammyShuck__HappyWeight.apk